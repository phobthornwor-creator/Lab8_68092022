from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def index(request):
    return render(request,"myapp/index.html")

def about(request):
    return render(request,"myapp/about.html")

def form(request):
    return render(request,"myapp/form.html")

def contact(request):
    return render(request, 'myapp/contact.html')